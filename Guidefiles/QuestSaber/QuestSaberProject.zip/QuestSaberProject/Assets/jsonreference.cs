﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BMBFmod
{
    [ExecuteInEditMode]
    public class jsonreference : MonoBehaviour
    {
        public BMBFmod.mod bmbfmod = new BMBFmod.mod();
    }
}
