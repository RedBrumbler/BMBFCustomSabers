﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BMBFmod
{
    [ExecuteInEditMode]
    public class jsonreference : MonoBehaviour
    {
        public BMBFmod.mod bmbfmod = new BMBFmod.mod();
        
        private string type { get; set;  } = "FileCopyMod";
        private string sourceFileName { get; set; }
        private string targetRootedPathAndFileName { get; set;  } = "/sdcard/Android/data/com.beatgames.beatsaber/files/sabers/testSaber.qsaber";

        public string coverImageFilename;
        public string icon;
        public string version;
        public string link;
        public List<string> description;
        public string gameVersion;
        private string platform { get; } = "quest";
        private string id { get; set; }
        public string name;
        public string author;
        private string category { get; } = "Saber";
        
        /*
        void OnEnable()
        {
            //Type = "FileCopyMod";
            SourceFileName = name + ".qsaber";

            //bmbfmod.components = 1;
            bmbfmod.components.Clear();
            bmbfmod.components.Add(new Component());

            bmbfmod.components[0].Type = Type;
            bmbfmod.components[0].SourceFileName = SourceFileName;
            bmbfmod.components[0].TargetRootedPathAndFileName = TargetRootedPathAndFileName;
            
            bmbfmod.coverImageFilename = coverImageFilename;
            bmbfmod.icon = icon;
            bmbfmod.version = version;
            bmbfmod.links.pageLink = link;
            bmbfmod.description = description;
            bmbfmod.gameVersion = gameVersion;
            bmbfmod.platform = platform;
            bmbfmod.id = id;
            bmbfmod.name = name;
            bmbfmod.author = author;
            bmbfmod.category = category;
            //TargetRootedPathAndFileName = "/sdcard/Android/data/com.beatgames.beatsaber/files/sabers/testSaber.qsaber";
            //platform = "quest";
            //category = "Saber";
            
            //bmbfmod = mod.CreateFromJSON("{'coverImageFilename': 'Cover.png','icon': 'Cover.png','components': [{'Type': 'FileCopyMod','SourceFileName': 'SaberName.qsaber','TargetRootedPathAndFileName': '/sdcard/Android/data/com.beatgames.beatsaber/files/sabers/testSaber.qsaber'}],'version': '1.0.0','links': { 'pageLink': 'stuff'},'description': ['Mod Description'],'gameVersion': '1.4.2','platform': 'Quest','id': 'ModID','name': 'Mod name','author': 'yourname','category': 'Saber'}");
            
            
//            string modjson = @"{
//  ""coverImageFilename"": "".png"",
//  ""icon"": ""Cover.png"",
//  ""components"": [
//    {
//      ""Type"": ""FileCopyMod"",
//	  ""SourceFileName"": ""SaberName.qsaber"",
//      ""TargetRootedPathAndFileName"": ""/sdcard/Android/data/com.beatgames.beatsaber/files/sabers/testSaber.qsaber""
//    }
//  ],
//  ""version"": ""1.0.0"",
//  ""links"": { ""pageLink"": ""stuff""},
//  ""description"": [
//    ""Mod Description""
//  ],
//  ""gameVersion"": ""1.4.2"",
//  ""platform"": ""Quest"",
//  ""id"": ""ModID"",
//  ""name"": ""Mod name"",
//  ""author"": ""yourname"",
//  ""category"": ""Saber""
//}";


            Debug.Log(JsonUtility.ToJson(bmbfmod, true));
            
        }
        */
    }
}
