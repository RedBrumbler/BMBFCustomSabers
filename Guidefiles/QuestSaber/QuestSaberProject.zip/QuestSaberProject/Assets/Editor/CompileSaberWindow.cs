﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class CompileSaberWindow : EditorWindow
{
    private BMBFmod.jsonreference[] questsabers;
    
    [MenuItem("Window/QuestSaber Exporter")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(CompileSaberWindow),false , "QuestSaber Exporter");
    }

    void OnGUI()
    {
        GUILayout.Label("QuestSabers", EditorStyles.boldLabel);

		GUILayout.Space(20);
        
        foreach (BMBFmod.jsonreference saber in questsabers)
        {
			GUILayout.Label ("GameObject : " + saber.gameObject.name, EditorStyles.boldLabel);
            //saber.AuthorName = EditorGUILayout.TextField("Author name", saber.AuthorName);
            //saber.SaberName = EditorGUILayout.TextField("Saber name", saber.SaberName);
            //saber.bmbfmod.components.Clear();
            if (saber.bmbfmod.components[0] == null)
            {
                saber.bmbfmod.components.Add(new BMBFmod.Component());
            }
            saber.bmbfmod.components[0].type = "FileCopyMod";
            saber.bmbfmod.components[0].targetRootedPathAndFileName = "/sdcard/Android/data/com.beatgames.beatsaber/files/sabers/testSaber.qsaber";
            saber.bmbfmod.coverImageFilename = EditorGUILayout.TextField("Cover image name", saber.bmbfmod.coverImageFilename);
            saber.bmbfmod.icon = EditorGUILayout.TextField("Icon name", saber.bmbfmod.icon); 
            saber.bmbfmod.version = EditorGUILayout.TextField("Saber version", saber.bmbfmod.version); 
            saber.bmbfmod.links.pageLink = EditorGUILayout.TextField("Page link", saber.bmbfmod.links.pageLink);
            //saber.bmbfmod.description.Add(EditorGUILayout.TextField("Description", saber.bmbfmod.description[0]));

            if (saber.bmbfmod.description[0] == null)
            {
                saber.bmbfmod.description.Add("");
            }

            saber.bmbfmod.description[0] = EditorGUILayout.TextField("Description", saber.bmbfmod.description[0]);
            saber.bmbfmod.gameVersion = EditorGUILayout.TextField("Game version", saber.bmbfmod.gameVersion);
            saber.bmbfmod.platform = "quest";
            saber.bmbfmod.name = EditorGUILayout.TextField("Saber name", saber.bmbfmod.name); ;
            saber.bmbfmod.author = EditorGUILayout.TextField("Author name", saber.bmbfmod.author);
            saber.bmbfmod.category = "Saber";

            saber.bmbfmod.components[0].sourceFileName = saber.bmbfmod.name + ".qsaber";

            saber.bmbfmod.id = saber.bmbfmod.name + saber.bmbfmod.author + saber.bmbfmod.version;

            EditorGUI.BeginDisabledGroup (saber.transform.Find("LeftSaber") == null || saber.transform.Find("RightSaber") == null);
            if(GUILayout.Button("Export " + saber.bmbfmod.name))
            {
                GameObject saberObject = saber.gameObject;
                if (saberObject != null && saber != null)
                {
					string path = EditorUtility.SaveFilePanel("Save saber file", "", saber.bmbfmod.name + ".qsaber", "qsaber");
					Debug.Log(path == "");

					if (path != "") {
						string fileName = Path.GetFileName (path);
						string folderPath = Path.GetDirectoryName (path);

						Selection.activeObject = saberObject;
						EditorUtility.SetDirty (saber);
						EditorSceneManager.MarkSceneDirty (saberObject.scene);
						EditorSceneManager.SaveScene (saberObject.scene);
                        //PrefabUtility.CreatePrefab ("Assets/_CustomSaber.prefab", Selection.activeObject as GameObject);
                        PrefabUtility.SaveAsPrefabAsset(Selection.activeObject as GameObject, "Assets/_CustomSaber.prefab");
                        AssetBundleBuild assetBundleBuild = default(AssetBundleBuild);
						assetBundleBuild.assetNames = new string[] {
							"Assets/_CustomSaber.prefab"
						};

						assetBundleBuild.assetBundleName = fileName;

						BuildTargetGroup selectedBuildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
						BuildTarget activeBuildTarget = EditorUserBuildSettings.activeBuildTarget;

						BuildPipeline.BuildAssetBundles (Application.temporaryCachePath, new AssetBundleBuild[]{ assetBundleBuild }, 0, EditorUserBuildSettings.activeBuildTarget);
						EditorPrefs.SetString ("currentBuildingAssetBundlePath", folderPath);
						EditorUserBuildSettings.SwitchActiveBuildTarget (selectedBuildTargetGroup, activeBuildTarget);
						AssetDatabase.DeleteAsset ("Assets/_CustomSaber.prefab");
						File.Move (Application.temporaryCachePath + "/" + fileName, path);
						AssetDatabase.Refresh ();
						EditorUtility.DisplayDialog ("Exportation Successful!", "Exportation Successful!", "OK");
					} else {
						EditorUtility.DisplayDialog ("Exportation Failed!", "Path is invalid.", "OK");
					}
                }
                else
                {
					EditorUtility.DisplayDialog ("Exportation Failed!", "Saber GameObject is missing.", "OK");
                }
            }
			EditorGUI.EndDisabledGroup ();

			if (saber.transform.Find("LeftSaber") == null) {
				GUILayout.Label ("LeftSaber gameObject is missing", EditorStyles.boldLabel);
			}
			if (saber.transform.Find("RightSaber") == null) {
				GUILayout.Label ("RightSaber gameObject is missing", EditorStyles.boldLabel);
			}
			if (GetObjectBounds (saber.gameObject).extents.z * 2.0 > 2.0) {
				GUILayout.Label ("The saber might be too long", EditorStyles.boldLabel);
			}
			if (GetObjectBounds (saber.gameObject).extents.x * 2.0 > 1.0) {
				GUILayout.Label ("The saber might be too large", EditorStyles.boldLabel);
			}
			GUILayout.Space(20);

            if (GUILayout.Button("Export bmbfmod.json for " + saber.bmbfmod.name))
            {
                string json = JsonUtility.ToJson(saber.bmbfmod, true);
                Debug.Log(json == "{}");

                if (json != "{}")
                {
                    string path = EditorUtility.SaveFilePanel("Save bmbfmod.json", "", "bmbfmod.json", ".json");
                    Debug.Log(path == "");

                    if (path != "")
                    {
                        string folderPath = Path.GetDirectoryName(path);

                        File.WriteAllText(path, json);
                    }
                    else
                    {
                        EditorUtility.DisplayDialog("Exportation Failed!", "Path is invalid.", "OK");
                    }
                }
                else
                {
                    EditorUtility.DisplayDialog("Exportation Failed!", "Json is invalid", "OK");
                }
            }
		}
    }

    private void OnFocus()
    {
		questsabers = GameObject.FindObjectsOfType<BMBFmod.jsonreference>();
    }

	private Bounds GetObjectBounds(GameObject g){
		var b = new Bounds (g.transform.position, Vector3.zero);
		foreach (Renderer r in g.GetComponentsInChildren<Renderer>()) {
			b.Encapsulate (r.bounds);
		}
		return b;
	}
}