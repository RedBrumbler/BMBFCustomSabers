﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace BMBFmod
{
    [System.Serializable]
    public class Component
    {
        public string type;
        public string sourceFileName;
        public string targetRootedPathAndFileName;
    }
    [System.Serializable]
    public class Links
    {
        public string pageLink;
    }
    [System.Serializable]
    public class mod
    {
        public string coverImageFilename;
        public string icon;
        public List<Component> components;
        public string version;
        public Links links;
        public List<string> description;
        public string gameVersion;
        public string platform;
        public string id;
        public string name;
        public string author;
        public string category;
    }
}